export type Link = {
    id?: number,
    url: string,
    code?: string,// a interrogação diz que a variavel será opcional
    hits?: number
}