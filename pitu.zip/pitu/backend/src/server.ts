//responsável por subir a aplicação e configurar o banco

//importando o app
import { ConnectionError, Error } from 'sequelize/types';
import app from './app';
//alteração nao luiz
import express from 'express';

//import do script de conexão com o banco para inicializar o mesmo
import database from './database';
//import { FORCE } from 'sequelize/types/lib/index-hints';




//sincronozar o javascript com o banco
//database.sync({(FORCE:true)});
database.sync();
console.log("Database running at 3306");


//definindo a porta - versão não luiz
const port = 3001;


//inincializando a porta do server e escutando 
//app.listen(port); //versão luiz
if(!app.listen(port)){
    console.log("Falha na conexão");
}else{
    //mensagem informativa no console
    console.log('Server running at 3001');
}


