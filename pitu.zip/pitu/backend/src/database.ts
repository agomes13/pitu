import {Sequelize} from 'sequelize';

//configurando a string de conexao com o banco
const sequelize = new Sequelize('mysql://admin:@Albatroz#2020@localhost:3306/pitu');

export default sequelize;