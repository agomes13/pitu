//importa o express do typescript instalado e configurado na criação do projeto
import express from 'express';

//importando as rotas criadas no arquivo links.ts
import linksRouter from './routes/links';

import cors from 'cors';

//cria uma nova instancia do express
const app = express();

//configura nossa aplicação para o uso do formato json
app.use(express.json);

app.use(cors());

//configura o uso das rotas
app.use(linksRouter);

//exportando o app apos configurar para ser utilizado fora desta classe
export default app;


