//configurações especificas das rotas

//importa o componente Router do express, o que está entre chaves 
//significa que é apenas um componente a ser importado
import {Router} from 'express';

//importa as funções do controller links
import linksController from '../controllers/links';

//instancia de router
const router = Router();

//recebe os dados enviados pela url
router.post('/links', linksController.postLink);

//devolve os dados para url pega as estatisticas de acesso de um link específico
router.get('/links/:code', linksController.hitLink);

//pega as estatisticas de acesso de um link específico
router.get('/links/:code/stats', linksController.getLink);

//exportar as rotas apos configuralas, permitindo que sejam utilizadas fora desta classe
export default router;