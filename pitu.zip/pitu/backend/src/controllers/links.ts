//logica por tras de cada uma das rotas

import {Request, Response} from 'express';
import { formatDiagnostic } from 'typescript';

import {Link} from '../models/link';
import linksRepository from '../models/linksRepository';

// criando um array do tipo links
//const links : Link[] = [];//salvando em memoria

//let proxId = 1;//salvando em memoria

function generateCode(){
    let text = '';

    // lista para as possibilidades de caracteres do link curto
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'; 

    for(let i=0; i<5; i++)
        text +=possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

async function postLink(req: Request, res: Response){
    const link = req.body as Link;
    //link.id = proxId++; salvando em memoria
    link.code = generateCode();
    link.hits = 0;
    // sempre que colocar await tem que passar a função para async
    const result = await linksRepository.add(link);// salvando no banco
    if(!result.id)return res.status(400);
    link.id=result.id;
    //salva o que for retornado em link dentro de links
    //links.push(link);// salvando em memoria
    //res.send('pstLink');// salvando em memoria
    res.status(201).json(link);
}

async function getLink(req: Request, res: Response){
    
    const code = req.params.code as string;
    //salvando no banco
    const link = await linksRepository.findByCode(code);

    if(!link)
        res.sendStatus(404);
    else
        res.json(link);

    //salvando em memoria
    //const link = links.find(item=> item.code === code);

    if(!link)
        res.sendStatus(404);
    else
        res.json(link);

    //res.send('getLink');
    
}

function hitLink(req: Request, res: Response){
    
    const code = req.params.code as string;
    //salvando no banco
    const link = linksRepository.hit(code);

    if (!link)
        res.sendStatus(404);
    else{
        res.json(link);
    }


    //salvando em memoria
    //const index = links.findIndex(item => item.code === code);
/*
    if (index === -1)
        res.sendStatus(404);
    else{
        links[index].hits!++;// exclamação serve para dizer que se responsabiliza pelos dados que estiverem na variavel
        res.json(links[index]);
    }
*/     

    res.send('hitLink');
    
}

//exporta as funcions para receber requisições com a lógica para processar as requisições
export default {
    postLink,
    getLink,
    hitLink
}