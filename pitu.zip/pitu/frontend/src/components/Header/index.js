import React from 'react';
/* // testes
function Header(props){
    return(
        <>
        <p>Pitu Header : {props.title}</p>
        <p>{props.children}</p>
        </>
    )
}
*/

import {Logo, HeaderContainer} from './styles';
import Icone from'../../assets/icon.png';

function Header(props){
    return(
        <>
            <HeaderContainer>
                <Logo src={Icone} alt='Pitu - Encurtador de URL' />
                <h1>Pitu</h1>
                <p>{props.children}</p>
            </HeaderContainer>
        </>
    )
}

export default Header;