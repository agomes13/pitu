import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

// import do bootstrap que foi configurado no App.scss
// precisa do node-sass
//npm add node-sass@(versão conforme o node) ou
//yar add node-sass@(versão conforme o node)
import './App.scss';

//import dos icones globalmente
import { library } from '@fortawesome/fontawesome-svg-core'
//import { faCheckSquare} from '@fortawesome/free-solid-svg-icons'
import { faExclamationTriangle} from '@fortawesome/free-solid-svg-icons'

//disponibilizando os icones globalmente
//library.add(faCheckSquare)
library.add(faExclamationTriangle)
//fim import icones globalmente

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

