import Routes from './routes';

/*
function App() {
  return (
    <div>Pitu</div>
  );
}
*/

const App = () => <Routes />

export default App;
