import React from 'react';

class NotFoundPage extends React.Component{
    constructor(props){
        super(props);

    }
render(){
    return(
        <p>Pitu 404 - Not Found</p>
    )
}

}

export default NotFoundPage;