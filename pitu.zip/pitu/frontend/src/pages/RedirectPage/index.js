import React from 'react';

import Header from '../../components/Header';
import {Container} from 'react-bootstrap';
import { FontAwesomeIcon} from '@fortawesome/react-fontawesome';

import ShortnerService from '../../services/shortnerService';

import {StatsContainer} from './styles';


class RedirectPage extends React.Component{
    constructor(props){
        super(props);

        //aqui eu defino o estado inicial da minha página
        this.state = {
            isLoading: false,
            url:'',
            errorMessage:'',
        }

    }

    async componentDidMount(){
        const {code} = this.props.match.params;
        
        try {
            const service = new ShortnerService();
            const {url} = await service.getLink(code);

            window.location = url;
        } catch (error) {
            this.setState({isLoading:false, errorMessage:'Ops, a URL solicitada não existe'});
        }
    }
render(){
    /* //testes
    return(
        <p>Pitu RedirectPage</p>
    )
    */
    const {errorMessage} = this.state;

    return(
        <Container>
            {errorMessage? (
                <>
                <Header>
                    Seu novo encurtador de URL. :
                </Header>
                <StatsContainer className="text-center">
                    <FontAwesomeIcon size="3x" collor="#f8d7da" icon="exclamation-triangle" />
                    <p className="m-3">{errorMessage}</p>
                    <a className="btn btn-primary" href="/">Encurtar nova URL</a>
                </StatsContainer>
                </>
            ):(
                <p className="text-center">Redirecionando...</p>
            )}
            
        </Container>
    )
}

}

export default RedirectPage;