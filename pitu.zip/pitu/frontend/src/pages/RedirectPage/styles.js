import styled from 'styled-components';

export const StatsContainer = styled.div`
    display: block;
`
