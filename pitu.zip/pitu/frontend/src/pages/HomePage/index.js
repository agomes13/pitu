import React from 'react';
//importando container bootstrap
//import {Container} from 'react-bootstrap';

//importando os icones
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';

//importando o cabeçalho do pacote componentes
import Header from '../../components/Header';

import {ContentContainer, Form, AdsBlock} from './styles';

//importando as ferramentas que serão utuilizadas do bootstrap
import {Container, InputGroup, FormControl, Button, Alert, Spinner} from 'react-bootstrap';

import ShortnerService from '../../services/shortnerService';

//importando as variaveis de ambiente globais configuradas nos arquivos
//.env.development
//.env.production
import vars from '../../configs/vars';

class HomePage extends React.Component{
    constructor(props){
        super(props);

        this.state = {
            isLoading: false,
            url: '',
            code: '',
            errorMessage: '',
        }
    }

 handleSubmit = async(event)=>{
     event.preventDefault();

     const{url}=this.state;

     this.setState({isLoading:true, errorMessage:''});

     if(!url){
         this.setState({isLoading:false, errorMessage: 'Infomre uma URL para encurtar.'});
     }else{
        try{
            const service = new ShortnerService();
            const result = await service.generate({url});

            this.setState({isLoading: false, code: result.code})
        }catch(error){
            this.setState({isLoading: false, errorMessage: 'Ops!, ocorreu um erro ao tentar encurtar a URL.'});
        }
     }
 }   

 copyToClipboard=()=>{
     const element=this.inputURL;
     element.select();
     document.execCommand('copy');
 }
render(){
    /*
    return(
        <Container>
             <Header title="Titulo">Header customizado</Header>
            <FontAwesomeIcon icon="check-square" />
            Pitu HomePage
        </Container>
    )
*/
        const { isLoading, errorMessage, code} = this.state;
    return(
        <Container>
            <Header>Seu Novo Encurtador de URL. :) customizado</Header>
            <ContentContainer>
                <Form onSubmit={this.handleSubmit}>
                    <InputGroup className="mb-3">
                        <FormControl 
                            placeholder="Digite a URL para encurtar:"
                            defaultValue=""
                            onChange={e=>this.setState({url: e.target.value})}
                        />
                        <InputGroup.Append>
                            <Button variant="primary" type="submit">Encurtar</Button>
                        </InputGroup.Append>
                    </InputGroup>

                    {isLoading?(
                        <Spinner animation="border"/>
                    ):(
                        code && (
                            <>
                                <InputGroup className="mb-3">
                                    <FormControl 
                                        autofocus={true}
                                        defaultValue={vars.HOST_APP + code}
                                        onChange={e=>this.setState({url: e.target.value})}
                                        ref={(input)=>this.inputURL=input}
                                    />
                                    <InputGroup.Append>
                                        <Button variant="outline-secondary" onClick={()=>this.copyToClipboard()}>Copiar</Button>
                                    </InputGroup.Append>
                                </InputGroup>
                                <p>Para Acompanhar as Estatisticas, Acesse {vars.HOST_APP + code}/stats</p>
                            </>
                        )
                    )}
                    {errorMessage&&<Alert variant="danger">{errorMessage}</Alert>}
                </Form>
            </ContentContainer>
            <ContentContainer>
                <AdsBlock className="text-center">Adense</AdsBlock>
            </ContentContainer>
        </Container>
    )
}

}

export default HomePage;